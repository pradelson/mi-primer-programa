
puntos = int(input("digite sus puntos: ")) 

x = 15
z = 45
b = 55
y = 150
d = 300

if puntos == x:
  print("su nota es muy baja")

if puntos == z:
  print("su nota es buena")

if puntos == b:
  print("si nota es muy buena")

if puntos == y:
  print("su nota es excelente")       

if puntos == d:
  print("usted ha pasado de curso")  

 





