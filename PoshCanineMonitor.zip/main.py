

num1 = 34
num2 = 67
num3 = 56
num4 = 26

elige = input("elige entre 34,67,56 y 26: ")

if elige == '34':
  suma = num1 + num2
  print(suma)

elif elige == '67':
  suma = num2 + num3
  print(suma)

elif elige == '56':
  suma = num3 + num1
  print(suma)

elif elige == '26':
  suma = num4 + num3
  print(suma)

    
 
